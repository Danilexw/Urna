package br.com.poo.urna.app;



import br.com.poo.urna.dao.MongoDBConnection;
import br.com.poo.urna.dao.CandidatoDAO;
import br.com.poo.urna.model.Candidato;
import br.com.poo.urna.model.Partido;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Classe principal da aplicação da Urna Eletrônica Simplificada.
 * Gerencia o ciclo de vida da aplicação JavaFX e inicializa o banco de dados.
 */
public class Main extends Application { // [cite: 36]

    @Override
    public void start(Stage primaryStage) throws IOException { 
        // Inicializa a conexão com o MongoDB
        MongoDBConnection.getDatabase(); 

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/br/com/poo/urna/view/UrnaView.fxml")); 
        Parent root = loader.load();
        primaryStage.setScene(new Scene(root)); 
        primaryStage.show(); 
    }

    @Override
    public void stop() throws Exception { // [cite: 36]
        // Fecha a conexão com o MongoDB quando a aplicação é encerrada
        MongoDBConnection.closeConnection();
        super.stop(); 
    }





    public static void main(String[] args) { // [cite: 36]
        launch(args);
    }
}